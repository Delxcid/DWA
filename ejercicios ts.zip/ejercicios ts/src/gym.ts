class GYM{
    peso:number;
    estatura:number;
    constructor(peso: number, estatura:number){
        this.peso=peso
        this.estatura=estatura
    }
    public IMC(): void{
        let imc=(this.peso/(this.estatura*2));
        
        if (imc< 18.5){
            "bajo";
        }else if(imc>=18.5 && imc <= 24.9){
            "Normal";
        }else if(imc>=25 && imc <=29.9){
            "sobre peso";
        }else if(imc>30){
            "obesidad"
            
        }
        
        console.log("su imc es de: " + imc )
    }
}
let cliente = new GYM(105,1.76)





//ejercio numero 2

class conversor{
    temp:number;
constructor(temp:number){
    this.temp=temp;
}
public FC():void {
    let celsius = ((this.temp-32)*1.8)
    console.log("fahrenheit a celsius: "+ celsius)

}
public CF():void {
    let farenheit = ((this.temp*(9/5))+32)
    console.log("celsius a fahrenheit: "+farenheit)

}
public KF():void {
    let farenheit = (((this.temp-273.15)*(9/5))+32)
    console.log("Kelvin a fahrenheit: "+farenheit)

}public KC():void {
    let celsius = this.temp-273.15
    console.log("Kelvin a calsius: "+celsius)

}
}
let aire = new conversor(45); aire.CF();


class Instituto {
    nombre: string;
    falta: number;

    constructor(nombre: string, falta: number) {
        this.nombre = nombre;
        this.falta = falta;
    }

    public seleccion(): void {
        let monto: number = 0;
        let infraccion: string = "";

        if (this.falta === 1) {
            infraccion = "Llegada tardía";
            monto = 1;
        } else if (this.falta === 2) {
            infraccion = "Caminar por los pasillos en horas de clase";
            monto = 3;
        } else if (this.falta === 3) {
            infraccion = "No andar vestimenta apropiada";
            monto = 5;
        } else if (this.falta === 4) {
            infraccion = "No hacer uso adecuado de las instalaciones";
            monto = 10;
        } else {
            console.log("Falta no válida");
            return;
        }

        console.log(
            "Nombre: " + this.nombre +
            "\nFalta: " + infraccion +
            "\nTotal a pagar: $" + monto
        );

        let estudiante = new Instituto("ernesto", 2);
estudiante.seleccion();

    }
}

